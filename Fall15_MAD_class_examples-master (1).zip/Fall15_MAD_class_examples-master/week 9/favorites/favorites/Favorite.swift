//
//  Favorite.swift
//  favorites
//
//  Created by Aileen Pierce on 10/4/14.
//  Copyright (c) 2014 Aileen Pierce. All rights reserved.
//

import Foundation

class Favorite {
    var favBook : String?
    var favAuthor : String?
}